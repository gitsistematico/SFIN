<?php
extract($_REQUEST);
include_once ('../../conexion/conexion.php');
global $bd;
 // $functions;
function insertArticulo(
  $bd,$cod_producto,$cod_barras_producto ,$prod_nombre ,$cod_categoria ,$rad ,$prod_forma ,$prod_concentracion ,$prod_tipo_medida_concentracion ,
  $prod_contenido ,$prod_tipo_medida_contenido ,$prod_cant_ing ,$prod_tipo_unidad ,$prod_lote ,$prod_cant_detallada,$prod_cant_x_unid,$prod_tipo_unidad_detallada ,
  $prod_fecha_compra_dia ,$prod_fecha_compra_mes ,$prod_fecha_compra_ano ,$prod_sucursal ,$prod_fecha_ven_dia ,$prod_fecha_ven_mes ,
  $prod_precio_compra,$prod_precio_venta,$iva,$prod_margen_ganacia ,$prod_valor_ganacia ,$add_producto ,$cod_art_ofe ,$prod_det_ofe ,$prod_add_cantidades_ofe ,$delete_producto)
{
  $result = array();
  $max = "select if(max(cast(cod_articulo AS SIGNED)) is null,0,max(cast(cod_articulo AS SIGNED))) from articulo";
  $insert_articulo = "insert into articulo (cod_articulo,cod_barras,art_nombre,cod_categoria,cod_marca,art_forma,art_concentracion,"
                ."art_medida_concentracion,art_cotenido,art_medida_contenido,art_precio_compra,art_precio_venta,iva,art_margen_ganancia,art_valor_ganacia,art_descuento) "
                ." values "
                ."(lpad(".'$valorM'.",10,0)".",'$cod_barras_producto','$prod_nombre','$cod_categoria','marca','$prod_forma','$prod_concentracion',"
                ."'$prod_tipo_medida_concentracion','$prod_contenido','$prod_tipo_medida_contenido','$prod_precio_compra','$prod_precio_venta',"
                ."'$iva','$prod_margen_ganacia','$prod_valor_ganacia','0'"
                .")";
   $id_art = $bd->forzarInsert($bd,$insert_articulo,$max,1);
   if ($id_art)
   {
     $insert_inv = "insert into inventario (inv_cod_artiiculo,inv_cod_sucursal,inv_cant_ingreso,inv_cant_detallada,inv_cant_x_unidad) "
                 . "values ("
                 . "lpad('$id_art',10,0),'$prod_sucursal','$prod_cant_ing','$prod_cant_detallada','$prod_cant_x_unid')";
                 $inv = $bd->ejecutar($insert_inv);
                //  echo $insert_inv;
    $insert_oferta_amarre = "insert into ofertas (cod_amarre,cod_articulo,cod_sucursal,ofer_detalle,ofer_salida) "
                          . "values "
                          . "(lpad('$id_art',10,0),lpad('$id_art',10,0),'$prod_sucursal','$prod_nombre','1')";
                          // echo "llave=".$insert_oferta_amarre."<br>";
                          $ofts = $bd->ejecutar($insert_oferta_amarre);
      if ($cod_art_ofe)
      {
        foreach ($cod_art_ofe as $key => $value)
        {
          $insert_oferta = "insert into ofertas (cod_amarre,cod_articulo,cod_sucursal,ofer_detalle,ofer_salida) "
                         . "values "
                         . "(lpad('$id_art',10,0),'".$cod_art_ofe[$key]."','$prod_sucursal','".$prod_det_ofe[$key]."','".$prod_add_cantidades_ofe[$key]."')";
                         // echo "llave=".$insert_oferta."<br>";
                         $ofts = $bd->ejecutar($insert_oferta);
        }
      }

     $result['success'] = "REGISTRO EXITOSO";
     $id_articulo = str_pad($id_art,10,0,STR_PAD_LEFT);
     $result['id_articulo'] = $id_articulo;
     echo json_encode($result);
   }else {
     $result['Error'] = "ERROR GUARDANDO PRODUCTO";
     echo json_encode($result);
   }


}

 switch ($opcion)
 {
   case 'insert_articulo':
        insertArticulo($bd
        ,@$cod_producto
        ,@$cod_barras_producto
        ,@$prod_nombre
        ,@$cod_categoria
        ,@$rad
        ,@$prod_forma
        ,@$prod_concentracion
        ,@$prod_tipo_medida_concentracion
        ,@$prod_contenido
        ,@$prod_tipo_medida_contenido
        ,@$prod_cant_ing
        ,@$prod_tipo_unidad
        ,@$prod_lote
        ,@$prod_cant_detallada
        ,@$prod_cant_x_unid
        ,@$prod_tipo_unidad_detallada
        ,@$prod_fecha_compra_dia
        ,@$prod_fecha_compra_mes
        ,@$prod_fecha_compra_ano
        ,@$prod_sucursal
        ,@$prod_fecha_ven_dia
        ,@$prod_fecha_ven_mes
        ,@$prod_precio_compra
        ,@$prod_precio_venta
        ,@$iva
        ,@$prod_margen_ganacia
        ,@$prod_valor_ganacia
        ,@$add_producto
        ,@$cod_art_ofe
        ,@$prod_det_ofe
        ,@$prod_add_cantidades_ofe
        ,@$delete_producto
      );
     break;
 }
?>
