<?php
include('../../complementos/encabezado.php');
// echo "hola todos hp";

?>
    <form id="f_articulo" class="" action="f_producto.php" method="post">
      <header style="text-align:center">
        <h4><label for="">Creacion de Productos</label></h4>
      </header>

        <div class="container">
          <div class="row">
            <div class="col-sm-6" >
                  <label for="message-text" class="control-label">Codigo del Producto</label>
                  <input type="text" class="form-control" maxlength="12"
                  id="cod_producto" name="cod_producto"
                  style="width:100%">
            </div>
            <div class="col-sm-6">
                  <label for="message-text" class="control-label">Codigo de Barras</label>
                  <input type="text" class="form-control" maxlength="12"
                  id="cod_barras_producto" name="cod_barras_producto"
                  style="width:100%">
            </div>
          </div>

          <div class="row">
            <div class="col-sm-6" >
                  <label for="message-text" class="control-label">Nombre</label>
                  <input type="text" class="form-control" maxlength="12"
                  style="width:100%" id="prod_nombre" name="prod_nombre">
            </div>
            <div class="col-sm-6">
                  <label for="message-text" class="control-label">Categoria</label>
                  <input type="text" class="form-control" maxlength="12"
                  style="width:100%" id="cod_marca" name="cod_categoria">
            </div>
          </div>

          <div class="row">
            <div class="col-sm-6" >
                  <label for="message-text" class="control-label">Marca Nueva</label>
                  <div class="row">
                    <div class="col-sm-6" style="text-align:right !important;">
                      <input type="radio" class="form-control" maxlength="12" style="width:100%" id="rad_s" name="rad">
                    </div>
                    <div class="col-sm-6" style="text-align:left !important;">
                      <input type="radio" class="form-control" maxlength="12" style="width:100%" id="rad_n" name="rad">
                    </div>
                  </div>
            </div>
            <div class="col-sm-6">
                  <label for="message-text" class="control-label">Forma</label>
                  <input type="text" class="form-control" maxlength="12"
                  style="width:100%" id="prod_forma" name="prod_forma">
            </div>
          </div>
          <div class="row">
            <div class="col-sm-6">
              <label for="message-text" class="control-label">Concentracion</label>
              <div class="row">
                <div class="col-sm-6">
                  <input type="text" class="form-control" maxlength="12"
                  style="width:100%" id="prod_concentracion" name="prod_concentracion">
                </div>
                <div class="col-sm-6">
                  <select id="prod_tipo_medida_concentracion" name="prod_tipo_medida_concentracion">
                    <option value="kg">kg</option>
                    <option value="mg">mg</option>
                    <option value="g">g</option>
                    <option value="l">l</option>
                    <option value="ml">ml</option>
                  </select>
                </div>
              </div>
            </div>

            <div class="col-sm-6">
              <label for="message-text" class="control-label">Contenido o Medida</label>
              <div class="row">
                <div class="col-sm-6">
                  <input type="text" class="form-control" maxlength="12"
                  style="width:100%" id="prod_contenido" name="prod_contenido">
                </div>
                <div class="col-sm-6">
                  <select id="prod_tipo_medida_contenido" name="prod_tipo_medida_contenido">
                    <option value="kg">kg</option>
                    <option value="mg">mg</option>
                    <option value="g">g</option>
                    <option value="l">l</option>
                    <option value="ml">ml</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <!-- panel de informacion de opciones para articulos  -->
          <div class="row">
              <div class="col-sm-12">
                <nav class="nav nav-tabs" id="myTab" role="tablist" style="background-color: #e3f2fd;">
                  <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-inv" role="tab" aria-controls="nav-home" aria-expanded="true">Datos Inventario</a>
                  <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-fact" role="tab" aria-controls="nav-profile">Datos Facturacion</a>
                  <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-asoc" role="tab" aria-controls="nav-profile">Asociar Articulos</a>
                </nav>
                <div class="tab-content" id="nav-tabContent">
                  <div class="tab-pane fade show active" id="nav-inv" role="tabpanel" aria-labelledby="nav-home-tab"
                  style="background-color: #e3f2fd;">
                  <br><br>
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="row">
                          <div class="col-sm-5">
                            <label for="message-text" class="control-label">Cantidad de ingreso</label>
                          </div>
                          <div class="col-sm-3">
                            <input type="text" class="form-control" maxlength="12"
                            style="width:100%" id="prod_cant_ing" name="prod_cant_ing">
                          </div>
                          <div class="col-sm-4">
                            <select id="prod_tipo_unidad" name="prod_tipo_unidad">
                              <option value="und">kg</option>
                              <option value="kg">kg</option>
                              <option value="mg">mg</option>
                              <option value="g">g</option>
                              <option value="l">l</option>
                              <option value="ml">ml</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="row">
                          <div class="col-sm-4" >
                            <label for="message-text" class="control-label">Lote del Producto</label>
                          </div>
                          <div class="col-sm-4">
                            <input type="text" class="form-control" maxlength="12"
                            style="width:100%" id="prod_lote" name="prod_lote">
                          </div>
                          <div class="col-sm-4"></div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="row">
                          <div class="col-sm-5">
                            <label for="message-text" class="control-label">Cantidad Detallada</label>
                          </div>
                          <div class="col-sm-3">
                            <input type="text" class="form-control" maxlength="12"
                            style="width:100%" id="prod_cant_detallada" name="prod_cant_detallada">
                          </div>
                          <div class="col-sm-4">
                            <select id="prod_tipo_unidad_detallada" name="prod_tipo_unidad_detallada">
                              <option value="und">und</option>
                              <option value="kg">kg</option>
                              <option value="mg">mg</option>
                              <option value="g">g</option>
                              <option value="l">l</option>
                              <option value="ml">ml</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="row">
                          <div class="col-sm-4" >
                            <label for="message-text" class="control-label">Fecha Compra</label>
                          </div>
                          <div class="col-sm-2" style="text-align:left !importan;">
                            <input type="text" class="form-control" maxlength="2" style="width:100%" placeholder="DD"
                            id="prod_fecha_compra_dia" name="prod_fecha_compra_dia">
                          </div>
                          <div class="col-sm-2">
                            <input type="text" class="form-control" maxlength="2" style="width:100%" placeholder="MM"
                            id="prod_fecha_compra_mes" name="prod_fecha_compra_mes">
                          </div>
                          <div class="col-sm-4">
                            <input type="text" class="form-control" maxlength="4" style="width:100%" placeholder="AAAAA"
                            id="prod_fecha_compra_ano" name="prod_fecha_compra_ano">
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                          <div class="row">
                            <div class="col-sm-5">
                              <label for="message-text" class="control-label">Cantidad por unidad</label>
                            </div>
                            <div class="col-sm-7" style="text-align:right;">
                              <input type="text" class="form-control" maxlength="12"
                              style="width:100%" id="prod_cant_x_unid" name="prod_cant_x_unid">
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-6">

                        </div>
                    </div>

                    <div class="row">
                      <div class="col-sm-6">
                        <div class="row">
                          <div class="col-sm-5">
                            <label for="message-text" class="control-label">Sucursal</label>
                          </div>
                          <div class="col-sm-7">
                            <select style="width:100%" id="prod_sucursal" name="prod_sucursal">
                              <option value="000001">Giron</option>
                              <option value="000002">Bucaramanga</option>
                              <option value="000003">Piedecuesta</option>
                              <option value="000004">Floridablanca</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="row">
                          <div class="col-sm-4" >
                            <label for="message-text" class="control-label">Fecha Vencimiento</label>
                          </div>
                          <div class="col-sm-2" style="text-align:left !importan;">
                            <input type="text" class="form-control" maxlength="2" style="width:100%" placeholder="DD"
                            id="prod_fecha_ven_dia" name="prod_fecha_ven_dia">
                          </div>
                          <div class="col-sm-2">
                            <input type="text" class="form-control" maxlength="2" style="width:100%" placeholder="MM"
                            id="prod_fecha_ven_mes" name="prod_fecha_ven_mes">
                          </div>
                          <div class="col-sm-4">
                            <input type="text" class="form-control" maxlength="4" style="width:100%" placeholder="AAAAA"
                            id="prod_fecha_ven_mes" name="prod_fecha_ven_mes">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="nav-fact" role="tabpanel" aria-labelledby="nav-profile-tab"
                  style="background-color: #e3f2fd;">
                    <div class="row">
                      <div class="col-sm-6">
                        <label for="message-text" class="control-label">Precio de Compra:</label>
                        <input type="text" class="form-control" id="prod_precio_compra" name="prod_precio_compra" value="">
                      </div>
                      <div class="col-sm-6">
                        <label for="message-text" class="control-label">Precio de Venta:</label>
                        <input type="text" class="form-control" id="prod_precio_venta" name="prod_precio_venta" value="">
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-6">
                        <label for="message-text" class="control-label">Manejo de Iva</label>
                        <div class="row">
                          <div class="col-sm-5" style="text-align: right;">
                              <label for="message-text" class="control-label">Si:</label>
                          </div>
                          <div class="col-sm-1">
                              <input type="radio" class="form-control" style="width:100%" name="iva" value="Si">
                          </div>
                          <div class="col-sm-5" style="text-align: right;">
                              <label for="message-text" class="control-label">No:</label>
                          </div>
                          <div class="col-sm-1">
                              <input type="radio" class="form-control" style="width:100%" name="iva" value="No">
                          </div>
                        </div>

                      </div>
                      <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-6">
                              <label for="message-text" class="control-label">Margen de Ganancia:</label>
                              <input type="text" class="form-control" id="prod_margen_ganacia" name="prod_margen_ganacia" value="">
                            </div>
                            <div class="col-sm-6">
                              <label for="message-text" class="control-label">Valor:</label>
                              <input type="text" class="form-control" id="prod_valor_ganacia" name="prod_valor_ganacia" value="">
                            </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="tab-pane fade" id="nav-asoc" role="tabpanel" aria-labelledby="nav-profile-tab" style="background-color: #e3f2fd;">
                    <div class="row" style="text-align:center;">
                      <div class="col-sm-3">
                        <label for="message-text" class="control-label">Codigo Articulo</label>
                      </div>
                      <div class="col-sm-3">
                        <label for="message-text" class="control-label">Detalla</label>
                      </div>
                      <div class="col-sm-3">
                        <label for="message-text" class="control-label">Cantidad</label>
                      </div>
                      <div class="col-md-3">
                        <button type="button" class="btn btn-primary" id="add_producto" name="add_producto">
                          <span class="typcn typcn-plus"></span>
                        </button>
                      </div>
                    </div>

                    <div class="row insert_oferta" id="oferta" style="text-align:center;display:none">
                      <div class="col-sm-3">
                        <input class="form-control" type="text" id="cod_art" name="cod_art" value="">
                      </div>
                      <div class="col-sm-3">
                        <input class="form-control" type="text" id="prod_det" name="prod_det" value="">
                      </div>
                      <div class="col-sm-3">
                        <input class="form-control" type="text" id="prod_add_cantidades" name="prod_add_cantidades" value="">
                      </div>
                      <div class="col-sm-3">
                        <button type="button" class="btn btn-danger delete_prod" id="delete_producto" name="delete_producto">
                          <span class="typcn typcn-trash"></span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
        <br>
      <footer>
        <div class="footer">
          <button type="button" class="btn btn-primary" id="btn-guardar">Guardar</button>
        </div>
      </footer>
    </form>
<?php
include('../../complementos/pie.php');
?>
<script type="text/javascript" src="control.js?<?php echo $rando; ?>"></script>
