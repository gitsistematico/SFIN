var index_oferta = 0;
$(document).ready(function()
{
  $('select').select2();
});


$(document).on('click','#f_articulo #add_producto',function(e)
{
  index_oferta++;
    var $div = $('#oferta'),
        $clone = $div
                .clone()
                .css('display','')
                .removeAttr('id')
                .insertBefore($div);

    $clone.find('[id="cod_art"]').attr('id','cod_art'+index_oferta).end();
    $clone.find('[name="cod_art"]').attr('name','cod_art_ofe[' + index_oferta + ']').end();

    $clone.find('[id="prod_det"]').attr('id','prod_det'+index_oferta).end();
    $clone.find('[name="prod_det"]').attr('name','prod_det_ofe[' + index_oferta + ']').end();

    $clone.find('[id="prod_add_cantidades"]').attr('id','prod_add_cantidades'+index_oferta).end();
    $clone.find('[name="prod_add_cantidades"]').attr('name','prod_add_cantidades_ofe[' + index_oferta + ']').end();
    // $('#cod_art'+index_oferta).attr('name','cod_art['+index_oferta+']').end();
    // prod_det
    // prod_add_cantidades

});

$(document).on('click','#btn-guardar',function(e)
{
  var url = "clase_articulo.php";
  var datos = "opcion=insert_articulo&"+$('#f_articulo').serialize();
  var resultado = peticion_ajax('POST',url,datos,false,'json',null);
  if(resultado.success)
  {
    $("#cod_producto").val(resultado.id_articulo);
    alert(resultado.success);    
  }else {
    alert(resultado.Error);
  }


});
